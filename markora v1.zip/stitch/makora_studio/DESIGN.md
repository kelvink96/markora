# Design System Document

## 1. Overview & Creative North Star: "The Editorial Architect"

This design system is built to transform the act of writing from a utility into a premium, focused experience. Our Creative North Star is **"The Editorial Architect."** 

Unlike generic markdown editors that rely on cluttered toolbars and rigid borders, this system treats the interface as a high-end, physical workspace—think of a bespoke oak desk or a gallery wall. We achieve this through **Intentional Asymmetry** and **Tonal Depth**. By breaking the "template" look, we use significant white space and varied typographic scales to guide the eye. The UI doesn't just hold the content; it frames it with an authoritative, calm presence.

---

## 2. Colors & Surface Philosophy

The palette is rooted in a sophisticated neutral range, moving away from "pure" grays toward nuanced slates and charcoals to ensure the interface feels "alive" rather than sterile.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or layout containment. 
Boundaries must be defined solely through:
- **Background Color Shifts:** Use `surface-container-low` for sidebars sitting on a `surface` background.
- **Tonal Transitions:** Defining the edge of the editor via a subtle shift to `surface-container-lowest`.

### Surface Hierarchy & Nesting
Treat the UI as a series of nested, physical layers. Instead of a flat grid, stack surfaces to define importance:
- **Level 0 (Base):** `surface` (#f7f9fb) – The desk.
- **Level 1 (Navigation/Sidebars):** `surface-container` (#e8eff3) – The trays.
- **Level 2 (Active Editor):** `surface-container-lowest` (#ffffff) – The paper.
- **Level 3 (Overlays/Popovers):** `surface-bright` with Glassmorphism.

### The "Glass & Gradient" Rule
To elevate the "Soft Dark" and Light modes beyond standard presets:
- **Glassmorphism:** Use semi-transparent surface colors (e.g., `surface` at 80% opacity) with a `12px` to `20px` backdrop-blur for floating panels.
- **Signature Textures:** Apply a subtle linear gradient (from `primary` to `primary-container`) on main CTAs to inject "visual soul" into the professional gray-scale environment.

---

## 3. Typography: The Editorial Voice

We pair **Manrope** (Display/Headlines) with **Inter** (Body/Labels) to balance character with high-performance legibility.

- **The Display Scale:** Use `display-lg` (3.5rem) and `headline-lg` (2rem) with generous tracking (-0.02em) to create an "Editorial" feel in empty states or document headers.
- **The Body Scale:** The editor's core is `body-lg` (1rem, Inter). It is optimized for long-form reading with a line-height of 1.6 to prevent eye fatigue.
- **Hierarchy of Authority:** Use `title-sm` (Inter, Semibold) for sidebar headers, contrasted against `label-sm` for metadata. The weight shift, rather than color shift, defines the structure.

---

## 4. Elevation & Depth

We eschew traditional drop shadows for **Tonal Layering**.

- **The Layering Principle:** Depth is "found," not "applied." A `surface-container-highest` panel placed over a `surface` background provides all the separation required. 
- **Ambient Shadows:** For floating elements (menus, tooltips), use "Ambient Light" shadows. 
    - *Value:* `0 8px 32px rgba(42, 52, 57, 0.06)`. 
    - Shadows must be tinted with the `on-surface` color to feel natural.
- **The "Ghost Border" Fallback:** If a border is required for accessibility, use the `outline-variant` token at **15% opacity**. Never use 100% opaque lines.
- **Backdrop Integration:** Use `backdrop-filter: blur(10px)` on all modals to allow the editor's text to bleed through softly, ensuring the user never feels "disconnected" from their work.

---

## 5. Components

### Buttons
- **Primary:** High-contrast `primary` (#565e74) with `on-primary` text. Use `md` (0.375rem) roundedness to maintain a professional, slightly sharp desktop feel.
- **Secondary/Tertiary:** Use `surface-container-high` as the background. On hover, shift to `surface-container-highest`. No borders.

### The Markdown Editor Canvas
- **Forbid Divider Lines:** Separate the file tree, the editor, and the inspector using vertical white space (Scale `8` or `12`) and subtle background shifts (e.g., `surface-container` to `surface-container-lowest`).
- **Inputs:** Text fields should be "Underlined Only" or "Ghost Style" (background fill only), using `surface-variant` with a `2px` focus ring of `primary`.

### Chips & Metadata
- **Selection Chips:** Use `secondary-container` with `on-secondary-container`. Roundedness: `full`. These should feel like small, tactile "pebbles" in the UI.

### Navigation (Tabs/Sidebar)
- **Active State:** Indicated by a `primary` vertical "pill" (2px wide) and a subtle shift to `surface-container-highest`. Do not use "tabs" that look like buttons; use "tabs" that look like indexed folders.

---

## 6. Do’s and Don’ts

### Do
- **Do** use `surface-container-lowest` for the primary writing area to simulate the "focus" of a white sheet of paper.
- **Do** lean on the Spacing Scale (specifically `8` and `10`) to create "breathing rooms" between UI clusters.
- **Do** use `manrope` for document titles to give the user a sense of "publishing" rather than just "typing."

### Don’t
- **Don't** use a 1px border to separate the sidebar from the editor. Use a background shift from `#e8eff3` to `#ffffff`.
- **Don't** use pure black (#000) for Dark Mode. Use the "Soft Dark" tokens (`on-background` at varying opacities) to maintain a premium, ink-on-paper feel.
- **Don't** use high-intensity shadows. If the shadow is visible at first glance, it is too dark. It should be felt, not seen.

---

## 7. Tokens Reference (Abbreviated)

| Token | Value | Application |
| :--- | :--- | :--- |
| `surface` | #f7f9fb | Main App Background |
| `surface-container-lowest` | #ffffff | Active Editor Canvas |
| `primary` | #565e74 | Action Buttons & Branding |
| `on-surface` | #2a3439 | Primary Text (Ink) |
| `rounded-md` | 0.375rem | Standard Component Radius |
| `spacing-4` | 1rem | Standard Padding/Gutter |

*Designers should refer to the JSON schema for full Light/Soft-Dark mappings.*